import { Link } from "react-router";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { ArrowLeft, Download, Share2 } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

const sentimentData = [
  { name: "Positive", value: 72, color: "#10b981" },
  { name: "Neutral", value: 16, color: "#f59e0b" },
  { name: "Negative", value: 12, color: "#ef4444" },
];

const keywordData = [
  { keyword: "Battery Life", count: 156 },
  { keyword: "Design", count: 134 },
  { keyword: "Display", count: 128 },
  { keyword: "Performance", count: 112 },
  { keyword: "Features", count: 98 },
  { keyword: "Value", count: 87 },
  { keyword: "Comfort", count: 76 },
  { keyword: "Connectivity", count: 65 },
];

const topKeywords = [
  "battery", "display", "design", "performance", "quality", "features", "comfortable",
  "easy", "fast", "reliable", "premium", "durable", "sleek", "innovative"
];

export function ReportDetails() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/app/history">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to History
            </Button>
          </Link>
          <div>
            <h1 className="text-4xl font-bold">Smart Watch X</h1>
            <p className="text-muted-foreground mt-1">Detailed Analytics Report</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
          <Button variant="primary">
            <Download className="w-4 h-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card glass className="text-center">
          <p className="text-muted-foreground mb-2">Positive Sentiment</p>
          <p className="text-5xl font-bold text-emerald-400 mb-2">72%</p>
          <Badge variant="positive">Excellent</Badge>
        </Card>
        <Card glass className="text-center">
          <p className="text-muted-foreground mb-2">Neutral Sentiment</p>
          <p className="text-5xl font-bold text-amber-400 mb-2">16%</p>
          <Badge variant="neutral">Good</Badge>
        </Card>
        <Card glass className="text-center">
          <p className="text-muted-foreground mb-2">Negative Sentiment</p>
          <p className="text-5xl font-bold text-red-400 mb-2">12%</p>
          <Badge variant="negative">Low</Badge>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card glass>
          <h3 className="text-xl font-semibold mb-6">Sentiment Distribution</h3>
          <ResponsiveContainer width="100%" height={350}>
            <PieChart>
              <Pie
                data={sentimentData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}%`}
                outerRadius={120}
                fill="#8884d8"
                dataKey="value"
              >
                {sentimentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card glass>
          <h3 className="text-xl font-semibold mb-6">Keyword Frequency Analysis</h3>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={keywordData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis dataKey="keyword" stroke="#94a3b8" angle={-45} textAnchor="end" height={100} />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(30, 41, 59, 0.9)",
                  border: "1px solid rgba(148, 163, 184, 0.1)",
                  borderRadius: "0.75rem",
                }}
              />
              <Bar dataKey="count" fill="#6366f1" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card glass>
        <h3 className="text-xl font-semibold mb-6">Word Cloud - Top Keywords</h3>
        <div className="flex flex-wrap gap-3 justify-center py-8">
          {topKeywords.map((keyword, index) => {
            const sizes = ["text-sm", "text-base", "text-lg", "text-xl", "text-2xl", "text-3xl"];
            const colors = ["text-primary", "text-secondary", "text-emerald-400", "text-amber-400", "text-indigo-400"];
            const size = sizes[Math.floor(Math.random() * sizes.length)];
            const color = colors[Math.floor(Math.random() * colors.length)];
            
            return (
              <span
                key={index}
                className={`${size} ${color} font-semibold px-2 py-1 hover:scale-110 transition-transform cursor-pointer`}
              >
                {keyword}
              </span>
            );
          })}
        </div>
      </Card>

      <Card glass>
        <h3 className="text-xl font-semibold mb-6">Customer Insights</h3>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h4 className="font-semibold text-emerald-400 mb-4 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">✓</span>
              What Customers Love
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <span className="text-emerald-400 mt-1">•</span>
                <div>
                  <p className="font-medium">Outstanding Battery Life</p>
                  <p className="text-sm text-muted-foreground">Customers consistently praise the long-lasting battery performance</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-emerald-400 mt-1">•</span>
                <div>
                  <p className="font-medium">Premium Design & Build Quality</p>
                  <p className="text-sm text-muted-foreground">Sleek design and solid construction highly appreciated</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-emerald-400 mt-1">•</span>
                <div>
                  <p className="font-medium">Vibrant Display</p>
                  <p className="text-sm text-muted-foreground">High-quality screen praised for clarity and brightness</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-emerald-400 mt-1">•</span>
                <div>
                  <p className="font-medium">Smooth Performance</p>
                  <p className="text-sm text-muted-foreground">Fast and responsive operation with no lag</p>
                </div>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-red-400 mb-4 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center">!</span>
              Areas for Improvement
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <span className="text-red-400 mt-1">•</span>
                <div>
                  <p className="font-medium">Limited App Ecosystem</p>
                  <p className="text-sm text-muted-foreground">Some users want more third-party app support</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-red-400 mt-1">•</span>
                <div>
                  <p className="font-medium">Premium Pricing</p>
                  <p className="text-sm text-muted-foreground">Price point is high compared to competitors</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-red-400 mt-1">•</span>
                <div>
                  <p className="font-medium">Connectivity Issues</p>
                  <p className="text-sm text-muted-foreground">Occasional Bluetooth pairing problems reported</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </Card>

      <Card glass>
        <h3 className="text-xl font-semibold mb-6">Recommendations</h3>
        <div className="space-y-4">
          <div className="flex items-start gap-4 p-4 rounded-xl bg-primary/10 border border-primary/20">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold">1</span>
            </div>
            <div>
              <p className="font-semibold mb-1">Expand App Store</p>
              <p className="text-sm text-muted-foreground">Partner with more developers to increase available applications and improve the ecosystem</p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-xl bg-primary/10 border border-primary/20">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold">2</span>
            </div>
            <div>
              <p className="font-semibold mb-1">Improve Connectivity Firmware</p>
              <p className="text-sm text-muted-foreground">Release software updates to address Bluetooth pairing and connection stability issues</p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-xl bg-primary/10 border border-primary/20">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold">3</span>
            </div>
            <div>
              <p className="font-semibold mb-1">Leverage Strong Points in Marketing</p>
              <p className="text-sm text-muted-foreground">Emphasize battery life, display quality, and premium design in promotional materials</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
