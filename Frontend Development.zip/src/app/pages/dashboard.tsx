import { Card } from "../components/ui/card";
import { StatCard } from "../components/ui/stat-card";
import { Package, MessageSquare, TrendingUp, Calendar } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

const sentimentData = [
  { name: "Positive", value: 65, color: "#10b981" },
  { name: "Neutral", value: 20, color: "#f59e0b" },
  { name: "Negative", value: 15, color: "#ef4444" },
];

const trendData = [
  { month: "Jan", positive: 60, neutral: 25, negative: 15 },
  { month: "Feb", positive: 62, neutral: 23, negative: 15 },
  { month: "Mar", positive: 65, neutral: 20, negative: 15 },
  { month: "Apr", positive: 68, neutral: 18, negative: 14 },
  { month: "May", positive: 70, neutral: 17, negative: 13 },
  { month: "Jun", positive: 72, neutral: 16, negative: 12 },
];

const recentAnalyses = [
  { product: "Wireless Headphones Pro", reviews: 1247, sentiment: "positive", date: "2026-03-08" },
  { product: "Smart Watch X", reviews: 892, sentiment: "positive", date: "2026-03-07" },
  { product: "Laptop Stand Elite", reviews: 456, sentiment: "neutral", date: "2026-03-06" },
  { product: "USB-C Hub Premium", reviews: 678, sentiment: "positive", date: "2026-03-05" },
];

export function Dashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's an overview of your sentiment analytics.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          icon={Package}
          label="Total Products Analyzed"
          value={47}
          trend="+12% from last month"
          trendUp
        />
        <StatCard
          icon={MessageSquare}
          label="Total Reviews Processed"
          value="12.4K"
          trend="+8% from last month"
          trendUp
        />
        <StatCard
          icon={TrendingUp}
          label="Average Sentiment Score"
          value="72%"
          trend="+5% from last month"
          trendUp
        />
        <StatCard
          icon={Calendar}
          label="Last Analysis"
          value="Today"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card glass>
          <h3 className="text-xl font-semibold mb-6">Overall Sentiment Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={sentimentData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {sentimentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card glass>
          <h3 className="text-xl font-semibold mb-6">Sentiment Trends Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis dataKey="month" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(30, 41, 59, 0.9)",
                  border: "1px solid rgba(148, 163, 184, 0.1)",
                  borderRadius: "0.75rem",
                }}
              />
              <Legend />
              <Line type="monotone" dataKey="positive" stroke="#10b981" strokeWidth={2} />
              <Line type="monotone" dataKey="neutral" stroke="#f59e0b" strokeWidth={2} />
              <Line type="monotone" dataKey="negative" stroke="#ef4444" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card glass>
        <h3 className="text-xl font-semibold mb-6">Recent Analyses</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Product</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Reviews</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Sentiment</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Date</th>
              </tr>
            </thead>
            <tbody>
              {recentAnalyses.map((analysis, index) => (
                <tr key={index} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="py-4 px-4 font-medium">{analysis.product}</td>
                  <td className="py-4 px-4 text-muted-foreground">{analysis.reviews}</td>
                  <td className="py-4 px-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm ${
                        analysis.sentiment === "positive"
                          ? "bg-emerald-500/20 text-emerald-400"
                          : analysis.sentiment === "neutral"
                          ? "bg-amber-500/20 text-amber-400"
                          : "bg-red-500/20 text-red-400"
                      }`}
                    >
                      {analysis.sentiment}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-muted-foreground">{analysis.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
