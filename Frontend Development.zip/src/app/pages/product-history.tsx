import { useState } from "react";
import { Link } from "react-router";
import { Card } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { StatCard } from "../components/ui/stat-card";
import { Search, Eye, RefreshCw, Trash2, Package, TrendingUp } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Wireless Headphones Pro",
    url: "https://example.com/product/123",
    reviews: 1247,
    positive: 68,
    neutral: 18,
    negative: 14,
    date: "2026-03-08",
  },
  {
    id: 2,
    name: "Smart Watch X",
    url: "https://example.com/product/456",
    reviews: 892,
    positive: 72,
    neutral: 16,
    negative: 12,
    date: "2026-03-07",
  },
  {
    id: 3,
    name: "Laptop Stand Elite",
    url: "https://example.com/product/789",
    reviews: 456,
    positive: 55,
    neutral: 30,
    negative: 15,
    date: "2026-03-06",
  },
  {
    id: 4,
    name: "USB-C Hub Premium",
    url: "https://example.com/product/012",
    reviews: 678,
    positive: 65,
    neutral: 22,
    negative: 13,
    date: "2026-03-05",
  },
  {
    id: 5,
    name: "Mechanical Keyboard RGB",
    url: "https://example.com/product/345",
    reviews: 1089,
    positive: 70,
    neutral: 18,
    negative: 12,
    date: "2026-03-04",
  },
];

export function ProductHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sentimentFilter, setSentimentFilter] = useState("all");

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSentiment =
      sentimentFilter === "all" ||
      (sentimentFilter === "positive" && product.positive > 60) ||
      (sentimentFilter === "neutral" && product.positive >= 50 && product.positive <= 60) ||
      (sentimentFilter === "negative" && product.positive < 50);
    return matchesSearch && matchesSentiment;
  });

  const avgSentiment = Math.round(
    products.reduce((acc, p) => acc + p.positive, 0) / products.length
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2">Product Analysis History</h1>
        <p className="text-muted-foreground">
          View and manage all your previously analyzed products
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <StatCard
          icon={Package}
          label="Total Products Analyzed"
          value={products.length}
        />
        <StatCard
          icon={TrendingUp}
          label="Average Sentiment Score"
          value={`${avgSentiment}%`}
        />
      </div>

      <Card glass>
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search product name..."
              className="pl-12"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSentimentFilter("all")}
              className={`px-4 py-2 rounded-xl transition-colors ${
                sentimentFilter === "all"
                  ? "bg-primary text-white"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              All
            </button>
            <button
              onClick={() => setSentimentFilter("positive")}
              className={`px-4 py-2 rounded-xl transition-colors ${
                sentimentFilter === "positive"
                  ? "bg-emerald-500 text-white"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              Positive
            </button>
            <button
              onClick={() => setSentimentFilter("neutral")}
              className={`px-4 py-2 rounded-xl transition-colors ${
                sentimentFilter === "neutral"
                  ? "bg-amber-500 text-white"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              Neutral
            </button>
            <button
              onClick={() => setSentimentFilter("negative")}
              className={`px-4 py-2 rounded-xl transition-colors ${
                sentimentFilter === "negative"
                  ? "bg-red-500 text-white"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              Negative
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Product Name</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Total Reviews</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Positive</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Neutral</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Negative</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Date Analyzed</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((product) => (
                <tr key={product.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="py-4 px-4">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground truncate max-w-xs">{product.url}</p>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-muted-foreground">{product.reviews}</td>
                  <td className="py-4 px-4">
                    <span className="text-emerald-400 font-medium">{product.positive}%</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-amber-400 font-medium">{product.neutral}%</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-red-400 font-medium">{product.negative}%</span>
                  </td>
                  <td className="py-4 px-4 text-muted-foreground">{product.date}</td>
                  <td className="py-4 px-4">
                    <div className="flex gap-2">
                      <Link to={`/app/reports/${product.id}`}>
                        <button className="p-2 rounded-lg hover:bg-muted transition-colors" title="View Report">
                          <Eye className="w-4 h-4" />
                        </button>
                      </Link>
                      <button className="p-2 rounded-lg hover:bg-muted transition-colors" title="Re-analyze">
                        <RefreshCw className="w-4 h-4" />
                      </button>
                      <button className="p-2 rounded-lg hover:bg-destructive/20 text-destructive transition-colors" title="Delete">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No products found matching your criteria</p>
          </div>
        )}
      </Card>
    </div>
  );
}
