import { Link } from "react-router";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { ArrowLeft, Download } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

const sentimentData = [
  { name: "Positive", value: 68, color: "#10b981" },
  { name: "Neutral", value: 18, color: "#f59e0b" },
  { name: "Negative", value: 14, color: "#ef4444" },
];

const keywordData = [
  { keyword: "Quality", count: 342 },
  { keyword: "Price", count: 287 },
  { keyword: "Fast Shipping", count: 256 },
  { keyword: "Easy to Use", count: 198 },
  { keyword: "Durable", count: 176 },
  { keyword: "Customer Service", count: 134 },
];

const sampleReviews = [
  {
    text: "This product exceeded my expectations! The quality is outstanding and it arrived quickly.",
    sentiment: "positive" as const,
    processed: "product exceeded expectations quality outstanding arrived quickly",
  },
  {
    text: "Good product overall, but the price is a bit high for what you get.",
    sentiment: "neutral" as const,
    processed: "good product price high",
  },
  {
    text: "Disappointed with the build quality. Expected better for this price point.",
    sentiment: "negative" as const,
    processed: "disappointed build quality expected better price",
  },
];

export function AnalysisResults() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/app/analyze">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-4xl font-bold">Wireless Headphones Pro</h1>
            <p className="text-muted-foreground mt-1">Analysis completed on March 10, 2026</p>
          </div>
        </div>
        <Button variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card glass className="text-center">
          <p className="text-muted-foreground mb-2">Positive</p>
          <p className="text-5xl font-bold text-emerald-400 mb-2">68%</p>
          <Badge variant="positive">Strong Performance</Badge>
        </Card>
        <Card glass className="text-center">
          <p className="text-muted-foreground mb-2">Neutral</p>
          <p className="text-5xl font-bold text-amber-400 mb-2">18%</p>
          <Badge variant="neutral">Average</Badge>
        </Card>
        <Card glass className="text-center">
          <p className="text-muted-foreground mb-2">Negative</p>
          <p className="text-5xl font-bold text-red-400 mb-2">14%</p>
          <Badge variant="negative">Needs Attention</Badge>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card glass>
          <h3 className="text-xl font-semibold mb-6">Sentiment Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={sentimentData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {sentimentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card glass>
          <h3 className="text-xl font-semibold mb-6">Most Common Keywords</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={keywordData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis type="number" stroke="#94a3b8" />
              <YAxis type="category" dataKey="keyword" stroke="#94a3b8" width={120} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(30, 41, 59, 0.9)",
                  border: "1px solid rgba(148, 163, 184, 0.1)",
                  borderRadius: "0.75rem",
                }}
              />
              <Bar dataKey="count" fill="#6366f1" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card glass>
        <h3 className="text-xl font-semibold mb-6">Key Insights</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-emerald-400 mb-3">What Customers Like</h4>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400">✓</span>
                <span className="text-muted-foreground">High product quality and durability</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400">✓</span>
                <span className="text-muted-foreground">Fast and reliable shipping</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400">✓</span>
                <span className="text-muted-foreground">Easy to use and set up</span>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-red-400 mb-3">Areas for Improvement</h4>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-red-400">✗</span>
                <span className="text-muted-foreground">Price point concerns from some customers</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400">✗</span>
                <span className="text-muted-foreground">Build quality inconsistencies reported</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400">✗</span>
                <span className="text-muted-foreground">Customer service response time</span>
              </li>
            </ul>
          </div>
        </div>
      </Card>

      <Card glass>
        <h3 className="text-xl font-semibold mb-6">Sample Reviews Analysis</h3>
        <div className="space-y-4">
          {sampleReviews.map((review, index) => (
            <div key={index} className="border border-border rounded-xl p-4">
              <div className="flex items-start justify-between mb-2">
                <Badge variant={review.sentiment}>{review.sentiment}</Badge>
              </div>
              <p className="text-foreground mb-2">{review.text}</p>
              <div className="text-sm">
                <p className="text-muted-foreground mb-1">Processed Text:</p>
                <p className="text-muted-foreground/70 italic">{review.processed}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
