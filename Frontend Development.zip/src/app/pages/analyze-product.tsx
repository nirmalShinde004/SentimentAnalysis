import { useState } from "react";
import { useNavigate } from "react-router";
import { Card } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Button } from "../components/ui/button";
import { Loader2 } from "lucide-react";

export function AnalyzeProduct() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"url" | "text">("url");
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    url: "",
    text: "",
  });

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      navigate("/app/results/1");
    }, 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2">Analyze Product</h1>
        <p className="text-muted-foreground">
          Enter a product URL or paste review text to analyze customer sentiment
        </p>
      </div>

      <Card glass>
        <div className="flex gap-4 mb-6 border-b border-border pb-4">
          <button
            onClick={() => setActiveTab("url")}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === "url"
                ? "bg-primary text-white"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Product URL
          </button>
          <button
            onClick={() => setActiveTab("text")}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === "text"
                ? "bg-primary text-white"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Paste Reviews
          </button>
        </div>

        <form onSubmit={handleAnalyze} className="space-y-6">
          {activeTab === "url" ? (
            <div>
              <label className="block mb-2 text-sm">Product URL</label>
              <Input
                type="url"
                placeholder="https://example.com/product/123"
                value={formData.url}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                required={activeTab === "url"}
              />
              <p className="text-sm text-muted-foreground mt-2">
                Enter the URL of a product page from Amazon, eBay, or other e-commerce sites
              </p>
            </div>
          ) : (
            <div>
              <label className="block mb-2 text-sm">Product Reviews</label>
              <Textarea
                placeholder="Paste customer reviews here, one per line or separated by paragraphs..."
                rows={12}
                value={formData.text}
                onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                required={activeTab === "text"}
              />
              <p className="text-sm text-muted-foreground mt-2">
                Paste multiple reviews. Our AI will analyze each one individually.
              </p>
            </div>
          )}

          <div className="bg-muted/30 rounded-xl p-4">
            <h4 className="font-semibold mb-2">What happens next?</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Our AI will extract and analyze all customer reviews</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Sentiment will be classified as Positive, Neutral, or Negative</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Key topics and keywords will be identified</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>You'll receive a comprehensive report with visualizations</span>
              </li>
            </ul>
          </div>

          <Button type="submit" variant="primary" size="lg" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Analyzing Reviews...
              </>
            ) : (
              "Analyze Sentiment"
            )}
          </Button>
        </form>
      </Card>

      {loading && (
        <Card glass className="text-center py-12">
          <Loader2 className="w-12 h-12 mx-auto mb-4 animate-spin text-primary" />
          <h3 className="text-xl font-semibold mb-2">Processing Your Request</h3>
          <p className="text-muted-foreground">
            Our AI is analyzing the reviews. This may take a few moments...
          </p>
          <div className="mt-6 max-w-md mx-auto bg-muted/30 rounded-full h-2">
            <div className="bg-gradient-to-r from-primary to-secondary h-full rounded-full animate-pulse w-3/4"></div>
          </div>
        </Card>
      )}
    </div>
  );
}
