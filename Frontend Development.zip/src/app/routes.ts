import { createBrowserRouter } from "react-router";
import { Root } from "./components/root";
import { Home } from "./pages/home";
import { Features } from "./pages/features";
import { About } from "./pages/about";
import { Contact } from "./pages/contact";
import { Login } from "./pages/login";
import { Register } from "./pages/register";
import { DashboardLayout } from "./components/dashboard-layout";
import { Dashboard } from "./pages/dashboard";
import { AnalyzeProduct } from "./pages/analyze-product";
import { AnalysisResults } from "./pages/analysis-results";
import { ProductHistory } from "./pages/product-history";
import { ReportDetails } from "./pages/report-details";
import { AccountSettings } from "./pages/account-settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "features", Component: Features },
      { path: "about", Component: About },
      { path: "contact", Component: Contact },
      { path: "login", Component: Login },
      { path: "register", Component: Register },
    ],
  },
  {
    path: "/app",
    Component: DashboardLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "analyze", Component: AnalyzeProduct },
      { path: "results/:id", Component: AnalysisResults },
      { path: "history", Component: ProductHistory },
      { path: "reports/:id", Component: ReportDetails },
      { path: "settings", Component: AccountSettings },
    ],
  },
]);
