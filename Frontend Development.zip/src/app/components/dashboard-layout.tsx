import { Outlet } from "react-router";
import { Sidebar } from "./sidebar";

export function DashboardLayout() {
  return (
    <div className="min-h-screen">
      <Sidebar />
      <main className="ml-64 p-8">
        <Outlet />
      </main>
    </div>
  );
}
